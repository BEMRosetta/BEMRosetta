#ifndef __WebCtrl__
#define __WebCtrl__

#include <Web/Web.h>
#include <CtrlLib/CtrlLib.h>
#include <TDraw/TDraw.h>
#include "DlgHttpServer.h"

#endif//__WebCtrl__
