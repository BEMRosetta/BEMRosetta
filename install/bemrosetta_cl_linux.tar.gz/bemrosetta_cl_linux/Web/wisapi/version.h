#define WISAPI_VERSION   "6.r16"
#define WISAPI_DATE      Date(2010, 4, 25)
#define WISAPI_COPYRIGHT "Copyright 1999-2010 Tomas Rylek"
