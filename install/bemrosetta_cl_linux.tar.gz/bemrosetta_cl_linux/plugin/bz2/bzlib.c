#ifdef flagWIN32

#include "lib/blocksort.c"
#include "lib/bzlib.c"
#include "lib/compress.c"
#include "lib/crctable.c"
#include "lib/decompress.c"
#include "lib/huffman.c"
#include "lib/randtable.c"

#endif
