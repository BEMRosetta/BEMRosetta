//#BLITZ_APPROVE

#define IMAGE_KEEP

#include "iml_header.h"

#undef IMAGE_KEEP

#include "iml_source.h"
