#define DLI_HEADER
#include <Core/dli.h>
