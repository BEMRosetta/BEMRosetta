// empty, uppsrc defaults for win32/x11 kick in
