#ifndef __temp_aux__Lang_s_h_
#define __temp_aux__Lang_s_h_

#define s_(x) txt##x

#endif
