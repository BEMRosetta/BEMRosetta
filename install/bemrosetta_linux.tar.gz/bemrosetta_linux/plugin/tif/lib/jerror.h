#ifndef jpeg_boolean
#define boolean jpeg_boolean
#define jpeg_boolean int
#endif
#include <plugin/jpg/lib/jerror.h>
