//#include "GridCtrl.h"


//class GridText : Ctrl
//{
//	private:
//		GridDisplay display;
//		WString* text;
//
//	public:
//
//		GridText() {}
//
//		virtual void Paint(Draw& w)
//		{
//			Rect r = GetRect();
//			display->Paint(w, r.left, r.top, r.Width(), r.Height(), *text, 0, fg, bg, fnt);
//		}
//
//
//};
